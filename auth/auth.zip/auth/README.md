# FireBaseAuth

Read this post for better understanding.<br/>
https://medium.com/@shohidshourov/firebase-login-and-registration-authentication-99ea25388cbf
